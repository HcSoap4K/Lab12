
#include <algorithm>
#include <cstdio>
#include <iostream>
const int N = 5000 + 5;
using namespace std;

int m, n, k;
int G[N][N];
int color[N];
int res;
void dfs(int x) {
    if (x == n + 1) {
        res++;
        return;
    } else {
        for (int i = 1; i <= k; i++) {
            bool flag = false;
            for (int y = 1; y <= x; y++) {
                if (G[x][y] == 1 && color[y] == i) {
                    flag = true;
                    break;
                }
            }
            if (flag == true)
                continue;

            color[x] = i;
            dfs(x + 1);
            color[x] = 0;
        }
    }
}
char mp[N][N];
int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);  // n个点m条边k种颜色
    for (int i = 1; i <= m; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        G[x][y] = 1;
        G[y][x] = 1;
    }
    dfs(1);
    if (res == 0)
        puts("NO");
    else
        printf("%d", res);
    return 0;
}